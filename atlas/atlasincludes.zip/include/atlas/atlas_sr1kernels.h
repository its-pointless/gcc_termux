/*
 * This file generated on line 730 of /data/data/com.termux/files/home/datlas/thread/../ATLAS//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_SR1KERNELS_H
   #define ATLAS_SR1KERNELS_H

void ATL_sgerk__900001
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_sgerk__3
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_sgerk__1
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);
void ATL_sgerk__1
   (ATL_CINT, ATL_CINT, const float*, const float*, float*, ATL_CINT);


#endif /* end guard around atlas_sr1kernels.h */
