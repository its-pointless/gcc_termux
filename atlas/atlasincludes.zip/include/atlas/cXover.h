#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 192
#define NN_MNK_M 238144
#define NN_MNK_N 141376
#define NN_MNK_MN 61440
#define NN_MNK_K 36864
#define NN_MNK_GE 27000
#define NT_MNK_M 238144
#define NT_MNK_N 238144
#define NT_MNK_MN 249856
#define NT_MNK_K 238144
#define NT_MNK_GE 226981
#define TN_MNK_M 238144
#define TN_MNK_N 57600
#define TN_MNK_MN 40960
#define TN_MNK_K 14400
#define TN_MNK_GE 13824
#define TT_MNK_M 141376
#define TT_MNK_N 238144
#define TT_MNK_MN 155648
#define TT_MNK_K 36864
#define TT_MNK_GE 27000
#define C2R_K 84

#endif
